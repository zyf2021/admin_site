<footer>
		<div class="wrapper">
		<div class="left">
			<p>Контактная информация:</p>
			<p>Телефон приемной 89997776655</p>
			<p>Техподдержка e-mail helpme@cherty.ru</p>
		</div>
		<div class="right">
			<p>Адрес:</p>
			<p>ул. Центральная д. 46</p>
			<p><a href="about.php">About</a></p>
		</div>
		</div>
	</footer>
</body>
</html>